import axios from 'axios';
import { useAuthStore } from '../store/authStore';

// Detect API URL based on current location
const getApiUrl = () => {
  const currentUrl = window.location.href;
  console.log('🔗 Current URL:', currentUrl);

  // For Telegram Web Apps (serveo, ngrok, etc.), always use localhost API
  // because the backend is running locally, not on the tunnel
  if (currentUrl.includes('serveo.net') || currentUrl.includes('ngrok.io') || currentUrl.includes('trycloudflare.com') || currentUrl.includes('loca.lt')) {
    const apiUrl = 'http://localhost:3000/api';
    console.log('📱 Telegram Web App detected - using localhost API:', apiUrl);
    return apiUrl;
  }

  // If running locally, use localhost
  if (currentUrl.includes('localhost') || currentUrl.includes('127.0.0.1')) {
    // Check if we're running in Docker container
    if (window.location.hostname === 'localhost' && window.location.port === '5173') {
      // We're running in Docker, use environment variable
      const apiUrl = (import.meta.env.VITE_API_URL || 'http://tg-backend:3000') + '/api';
      console.log('🐳 Docker detected - using env API URL:', apiUrl);
      return apiUrl;
    } else {
      // We're running locally on host
      const apiUrl = 'http://localhost:3000/api';
      console.log('🏠 Using localhost API URL:', apiUrl);
      return apiUrl;
    }
  }

  const fallbackUrl = import.meta.env.VITE_API_URL || 'http://localhost:3000/api';
  console.log('🔄 Using fallback API URL:', fallbackUrl);
  return fallbackUrl;
};

export const API_URL = getApiUrl();
console.log('Using API URL:', API_URL);
console.log('Environment variables:', import.meta.env);

export const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add request logging
api.interceptors.request.use((config) => {
  console.log('🌐 API Request:', config.method?.toUpperCase(), config.url);
  console.log('📝 Full URL:', config.baseURL + config.url);
  console.log('📦 Request data:', config.data || '(no data)');
  console.log('🔑 Request headers:', config.headers);
  return config;
});

// Add response logging
api.interceptors.response.use(
  (response) => {
    console.log('✅ API Response:', response.status, response.config.url);
    return response;
  },
  (error) => {
    console.error('❌ API Error:', error.response?.status || 'Network Error', error.config?.url || 'Unknown URL');
    console.error('❌ Error details:', error.response?.data || error.message);
    return Promise.reject(error);
  }
);

// Add auth token to requests
api.interceptors.request.use((config) => {
  const token = useAuthStore.getState().token;
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Handle auth errors and token refresh
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    if (error.response?.status === 401 && import.meta.env.DEV) {
      console.log('🔄 401 error detected, attempting token refresh...');

      try {
        // Try to refresh token
        await useAuthStore.getState().refreshToken();

        // Retry the original request with new token
        const newToken = useAuthStore.getState().token;
        if (newToken && error.config) {
          console.log('✅ Token refreshed, retrying request...');
          error.config.headers.Authorization = `Bearer ${newToken}`;
          return api.request(error.config);
        }
      } catch (refreshError) {
        console.error('❌ Token refresh failed:', refreshError);
        // Force logout on refresh failure
        useAuthStore.getState().logout();
      }
    }
    return Promise.reject(error);
  },
);

// Auth API
export const authApi = {
  loginAdmin: (initData?: string) => api.post('/auth/telegram/admin', { initData: initData || 'dev' }).then(res => res.data),
  loginUser: (initData: string) => api.post('/auth/telegram/user', { initData }).then(res => res.data),
  devLogin: (adminId?: string) => api.post('/auth/telegram/admin', { initData: 'dev' }).then(res => res.data),
};

// Stats API
export const statsApi = {
  getStats: () => api.get('/admin/stats').then(res => res.data),
  getFakeStats: () => api.get('/admin/stats/fake').then(res => res.data),
  getHistory: (days?: number) => api.get('/admin/stats/history', { params: { days } }).then(res => res.data),
  regenerateFakeStats: () => api.post('/admin/stats/fake/regenerate').then(res => res.data),
  getTopUsers: (limit?: number) => api.get('/admin/stats/top-users', { params: { limit } }).then(res => res.data),
};

// Users API
export const usersApi = {
  getUsers: (params?: any) => api.get('/admin/users', { params }).then(res => res.data),
  getUser: (id: string) => api.get(`/admin/users/${id}`).then(res => res.data),
  updateBalance: (tg_id: string, data: any) => api.post(`/admin/users/${tg_id}/balance`, data).then(res => res.data),
  blockUser: (id: string) => api.post(`/admin/users/${id}/block`).then(res => res.data),
  unblockUser: (id: string) => api.post(`/admin/users/${id}/unblock`).then(res => res.data),
  getBalanceLogs: (id: string, limit?: number) => api.get(`/admin/users/${id}/balance-logs`, { params: { limit } }).then(res => res.data),
};

// Payouts API
export const payoutsApi = {
  getPayouts: (params?: any) => api.get('/admin/payouts', { params }).then(res => res.data),
  getPayout: (id: string) => api.get(`/admin/payouts/${id}`).then(res => res.data),
  approvePayout: (id: string) => api.post(`/admin/payouts/${id}/approve`).then(res => res.data),
  declinePayout: (id: string, reason: string) =>
    api.post(`/admin/payouts/${id}/decline`, { reason }).then(res => res.data),
};

// Balance API
export const balanceApi = {
  getOverview: () => api.get('/admin/balance/overview').then(res => res.data),
  getLogs: (params?: any) => api.get('/admin/balance/logs', { params }).then(res => res.data),
  adjustBalance: (tg_id: string, amount: number, reason: string) =>
    api.post(`/admin/users/${tg_id}/balance`, { delta: amount, reason }).then(res => res.data),
};

// Settings API
export const settingsApi = {
  getSettings: () => api.get('/admin/settings').then(res => {
    console.log('🔧 Settings API response:', res);
    console.log('🔧 Settings API data:', res.data);
    console.log('🔧 Settings API data length:', res.data?.length);
    return res.data;
  }),
  getSetting: (key: string) => api.get(`/admin/settings/${key}`).then(res => res.data),
  updateSetting: (key: string, value: string) => api.put('/admin/settings', { settings: [{ key, value }] }).then(res => res.data),
  upsertSetting: (data: any) => api.post('/admin/settings', data).then(res => res.data),
  deleteSetting: (key: string) => api.delete(`/admin/settings/${key}`).then(res => res.data),
  updateSettings: (data: any) => api.put('/admin/settings', { settings: data }).then(res => res.data),

  // Advanced settings management
  getSettingsByCategories: () => api.get('/admin/settings/categories').then(res => res.data),
  getSettingsByCategory: (category: string) => api.get(`/admin/settings/category/${category}`).then(res => res.data),
  validateSettings: (settings: any) => api.post('/admin/settings/validate', { settings }).then(res => res.data),
  exportSettings: () => api.post('/admin/settings/export').then(res => res.data),
  importSettings: (settings: any) => api.post('/admin/settings/import', { settings }).then(res => res.data),
  resetSettings: (categories?: string[]) => api.post('/admin/settings/reset', { categories }).then(res => res.data),
  getSettingsHistory: (limit?: number, offset?: number) =>
    api.get('/admin/settings/history', { params: { limit, offset } }).then(res => res.data),
  searchSettings: (query: string, category?: string) =>
    api.get('/admin/settings/search', { params: { q: query, category } }).then(res => res.data),
  bulkUpdateSettings: (settings: any) => api.post('/admin/settings/bulk-update', { settings }).then(res => res.data),
};

// Settings History API
export const settingsHistoryApi = {
  getHistory: (limit?: number, offset?: number) =>
    api.get('/admin/settings/history', { params: { limit, offset } }).then(res => res.data),
};

// Broadcast API
export const broadcastApi = {
  sendBroadcast: (data: any) => api.post('/admin/broadcast', data).then(res => res.data),
};

// Buttons API
export const buttonsApi = {
  getButtons: (params?: any) => api.get('/admin/buttons', { params }).then(res => res.data),
  getButton: (id: string) => api.get(`/admin/buttons/${id}`).then(res => res.data),
  createButton: (data: any) => api.post('/admin/buttons', data).then(res => res.data),
  updateButton: (id: string, data: any) => api.put(`/admin/buttons/${id}`, data).then(res => res.data),
  deleteButton: (id: string) => api.delete(`/admin/buttons/${id}`).then(res => res.data),
};

// Scenarios API
export const scenariosApi = {
  getScenarios: (params?: any) => api.get('/admin/scenarios', { params }).then(res => res.data),
  getScenario: (id: string) => api.get(`/admin/scenarios/${id}`).then(res => res.data),
  createScenario: (data: any) => api.post('/admin/scenarios', data).then(res => res.data),
  updateScenario: (id: string, data: any) => api.put(`/admin/scenarios/${id}`, data).then(res => res.data),
  deleteScenario: (id: string) => api.delete(`/admin/scenarios/${id}`).then(res => res.data),
};

// Tasks API
export const tasksApi = {
  getTasks: (params?: any) => api.get('/admin/tasks', { params }).then(res => res.data),
  getTask: (id: string) => api.get(`/admin/tasks/${id}`).then(res => res.data),
  getTaskStats: (id: string) => api.get(`/admin/tasks/${id}/stats`).then(res => res.data),
  createTask: (data: any) => api.post('/admin/tasks', data).then(res => res.data),
  updateTask: (id: string, data: any) => api.put(`/admin/tasks/${id}`, data).then(res => res.data),
  deleteTask: (id: string) => api.delete(`/admin/tasks/${id}`).then(res => res.data),
};

// Chats API
export const chatsApi = {
  getChats: () => api.get('/admin/chats').then(res => res.data),
  getUnreadCount: () => api.get('/admin/chats/unread-count').then(res => res.data),
  getMessages: (userId: string, limit?: number) =>
    api.get(`/admin/chats/${userId}/messages`, { params: { limit } }).then(res => res.data),
  sendMessage: (userId: string, data: any) => api.post(`/admin/chats/${userId}/send`, data).then(res => res.data),
};

// Admins API
export const adminsApi = {
  getAdmins: () => api.get('/admin/admins').then(res => res.data),
  getAdmin: (id: string) => api.get(`/admin/admins/${id}`).then(res => res.data),
  createAdmin: (data: any) => api.post('/admin/admins', data).then(res => res.data),
  updateAdmin: (id: string, data: any) => api.put(`/admin/admins/${id}`, data).then(res => res.data),
  deleteAdmin: (id: string) => api.delete(`/admin/admins/${id}`).then(res => res.data),
};

// Media API
export const mediaApi = {
  uploadFile: (file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    return api.post('/admin/media/upload', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    }).then(res => res.data);
  },
};

